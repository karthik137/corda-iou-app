package com.template.flows;

import co.paralleluniverse.fibers.Suspendable;
import com.template.contracts.IOUContract;
import com.template.states.IOUState;
import net.corda.core.contracts.Command;
import net.corda.core.flows.*;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;

import java.security.PublicKey;
import java.util.Arrays;
import java.util.List;

// ******************
// * Initiator flow *
// ******************
@InitiatingFlow
@StartableByRPC
public class IOUFlow extends FlowLogic<Void> {

    private final Integer iouValue;
    private final Party otherParty;

    private final ProgressTracker progressTracker = new ProgressTracker();

    public IOUFlow(Integer iouValue, Party otherParty) {
        this.iouValue = iouValue;
        this.otherParty = otherParty;
    }

    @Override
    public ProgressTracker getProgressTracker() {
        return progressTracker;
    }

    @Suspendable
    @Override
    public Void call() throws FlowException {
        // IOU flow logic goes here.

        // get notary from network map cache
        Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);

        // We create transaction components
        IOUState newState = new IOUState(iouValue, getOurIdentity(), otherParty);
        // Command command = new Command<>(new IOUContract.Commands.Action(), getOurIdentity().getOwningKey());
        List<PublicKey> requiredSigners = Arrays.asList(getOurIdentity().getOwningKey(),
                otherParty.getOwningKey());
        Command command = new Command<>(new IOUContract.Create(), requiredSigners);


        // We create the transaction builder and add the components.
        TransactionBuilder txxBuilder = new TransactionBuilder(notary)
                .addOutputState(newState, IOUContract.ID)
                .addCommand(command);

        //Verify the transaction
        txxBuilder.verify(getServiceHub());

        // Signing the transaction
        SignedTransaction signTx  = getServiceHub().signInitialTransaction(txxBuilder);

        // Creating a session with the other party
        FlowSession otherPartySession = initiateFlow(otherParty);



        // Obtaining the counterparty's signature.
        SignedTransaction fullySignedTx = subFlow(new CollectSignaturesFlow(
                signTx, Arrays.asList(otherPartySession), CollectSignaturesFlow.tracker()
        ));

        // Finalising the transaction
        subFlow(new FinalityFlow(fullySignedTx, otherPartySession));

        //subFlow(new FinalityFlow(signTx, otherPartySession));
        return null;
    }
}
