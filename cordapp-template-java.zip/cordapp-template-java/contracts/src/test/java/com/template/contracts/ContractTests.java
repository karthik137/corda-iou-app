package com.template.contracts;

import net.corda.testing.node.MockServices;
import org.junit.Test;

public class ContractTests {
    private final MockServices ledgerServices = new MockServices();

    @Test
    public void dummyTest() {

    }
}